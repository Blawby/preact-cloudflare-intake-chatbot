// Import TeamConfig helpers from TeamService instead of defining it here
import { TeamConfig, buildDefaultTeamConfig } from './TeamService.js';
import { Logger } from '../utils/logger.js';
import type { Env } from '../types.js';
import type { Ai } from '@cloudflare/workers-types';

// Optimized AI Service with caching and timeouts
export class AIService {
  private teamConfigCache = new Map<string, { config: TeamConfig; timestamp: number }>();
  private readonly CACHE_TTL = 5 * 60 * 1000; // 5 minutes

  constructor(private ai: Ai, private env: Env) {
    // Initialize Logger with environment variables for Cloudflare Workers compatibility
    Logger.initialize({
      DEBUG: env.DEBUG,
      NODE_ENV: env.NODE_ENV
    });
  }
  
  async runLLM(
    messages: Array<Record<string, unknown>>,
    model: string = '@cf/openai/gpt-oss-20b'
  ) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000); // 30 second timeout
    
    try {
      // Type assertion to handle dynamic model strings - matches pattern used in analyze.ts
      const runModel = this.ai.run.bind(this.ai) as (model: string, payload: Record<string, unknown>) => Promise<unknown>;
      const result = await runModel(model, {
        messages,
        max_tokens: 500,
        temperature: 0.1, // Reduced from 0.4 to 0.1 for more factual responses
      });
      clearTimeout(timeout);
      return result;
    } catch (error) {
      clearTimeout(timeout);
      throw error;
    }
  }
  
  async getTeamConfig(teamId: string): Promise<TeamConfig> {
    Logger.debug('AIService.getTeamConfig called with teamId:', teamId);
    const cached = this.teamConfigCache.get(teamId);
    if (cached && Date.now() - cached.timestamp < this.CACHE_TTL) {
      Logger.debug('Returning cached team config');
      return cached.config;
    }

    try {
      // Use TeamService to get full team object
      const { TeamService } = await import('./TeamService.js');
      const teamService = new TeamService(this.env);
      const team = await teamService.getTeam(teamId);
      
      if (team) {
        Logger.logTeamConfig(team, true); // Include sanitized config in debug mode
        this.teamConfigCache.set(teamId, { config: team.config, timestamp: Date.now() });
        return team.config;
      } else {
        Logger.info('No team found in database');
        Logger.debug('Available teams:');
        const allTeams = await teamService.listTeams();
        Logger.debug('All teams:', allTeams.map(t => ({ id: t.id, slug: t.slug })));
      }
    } catch (error) {
      Logger.warn('Failed to fetch team config:', error);
    }
    Logger.info('Returning default team config');
    return buildDefaultTeamConfig(this.env);
  }

  // Clear cache for a specific team or all teams
  clearCache(teamId?: string): void {
    if (teamId) {
      this.teamConfigCache.delete(teamId);
    } else {
      this.teamConfigCache.clear();
    }
  }

  // Agent handles all conversation logic - no manual validation needed
} 
