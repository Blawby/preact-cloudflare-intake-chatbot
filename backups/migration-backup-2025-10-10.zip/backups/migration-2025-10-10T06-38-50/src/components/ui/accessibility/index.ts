export * from './ariaLabels';
